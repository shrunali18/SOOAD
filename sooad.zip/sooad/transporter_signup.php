<?php
	$servername ="localhost";
	$username = "root";
	$password = "";
	$dbname ="sooad";
	
	$conn1=new mysqli($servername,$username,$password,$dbname);
	if($conn1->connect_error)
	{
		die("Connection error:" .$conn1->connect_error);
	}
	
		

	$fname= $_POST['first_name'];
	$lname = $_POST['last_name'];
		$name=$fname.$lname;
		$phone_no = $_POST['phone_number'];
	$address = $_POST['area'];
	$city = $_POST['city_name'];
	$state = $_POST['state_name'];
	$email= $_POST['email'];
	$password= $_POST['password'];
	$vnp = $_POST['vnp'];
	$license = $_POST['license'];
	$aadhar = $_POST['aadhar_card'];
	
	
	
	$sql = "INSERT INTO transporter VALUES('$name','$phone_no','$address','$city','$state','$email','$password','$vnp','$license','$aadhar')";
	if($conn1->query($sql)===TRUE)
	{
		echo "New record crested successfully";
	}
	else
	{
		echo "error";
	}
				header("location:index.html");

	$conn1->close();
?>