<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "sooad";
	
	$conn1 = new mysqli($servername,$username,$password,$dbname);
	if($conn1->connect_error)
	{
		die("Connection error :" .$conn1->connect_error);
	}
	$conn1->close();
?>