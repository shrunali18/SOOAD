<?php
	//error_reporting(ALL);
	$servername = "localhost";//conections name
	$username = "root";//username is root by default for your computer
	$password = "";//password is blank here
	$dbname = "sooad";//database name is project
	
	//create connection
	$conn1 = new mysqli($servername ,$username ,$password ,$dbname);//we are passing all the values here ,this is used to create connection
	// check connection
	if($conn1->connect_error)
	{
		die("Connection failed :" .$conn1->connect_error);//if connection fails
		
	}
	
	$conn1->close();
?>