<?php
session_start();

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "sooad";
	$_SESSION['price']=0;
	
	$conn1 = new mysqli($servername,$username,$password,$dbname);
	if($conn1->connect_error)
	{
		die("Connection error :" .$conn1->connect_error);
	}
	//so that the form is not submitted empty

		if( isset($_POST['address']) && !empty($_POST['address']) AND isset($_POST['area']) && !empty($_POST['area']) AND isset($_POST['cost_per_sf']) && !empty($_POST['cost_per_sf']))//  If statement is true run code between brackets
			{
				
				$address = $_POST['address'];
				$phone_no = $_POST['phone_no'];
				$area = $_POST['area'];
				$cost_per_sf = $_POST['cost_per_sf'];
				
			}
		else
	{		
					echo "form not submitted";

	}
	
	$sql = "INSERT INTO producer_inside_rent(address,phone_no,area,cost) VALUES('$address','$phone_no','$area','$cost_per_sf');";
	if($conn1->query($sql)==TRUE)
	{
		echo "New record created.";
		$_SESSION['price'] = $area*$cost_per_sf;
			header("location:producer_inside_rent_submit.php");

	}
	else
	{
		echo "error";
	}
	
	
	$conn1->close();
?>