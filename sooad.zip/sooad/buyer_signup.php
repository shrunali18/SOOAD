<?php
	$servername = "localhost";
	$username ="root";
	$password = "";
	$dbname = "sooad";
	
	$conn1 = new mysqli($servername ,$username ,$password ,$dbname);
	if($conn1->connect_error)
	{
		die("Connection error :".$conn1->connect_error);
	}
	
		if( isset($_POST['first_name']) && !empty($_POST['first_name']) AND isset($_POST['last_namename']) && !empty($_POST['last_name']) AND isset($_POST['email']) && !empty($_POST['email']) ){//  If statement is true run code between brackets
		echo "dfsdf";
	} else
	{
	
	$fname = $_POST['first_name'];
	$lname = $_POST['last_name'];
	$name=$fname.$lname;
	$phone_no = $_POST['phone_number'];
	$address = $_POST['area'];
	$city = $_POST['city_name'];
	$state = $_POST['state_name'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$shopid = $_POST['Shopkeeper_ID'];
	$aadhar_card = $_POST['aadhar'];
	}
	
	$sql = " INSERT INTO buyer VALUES('$name','$phone_no','$address','$city','$state','$email','$password','$shopid','$aadhar_card')";//sql statement
	
	if($conn1->query($sql)===TRUE)
	{
		echo "New record created successfully ";
	}
	else
	{
		echo "wrong";
	}
	
	header("location:index.html");
	$conn1=close();
?>