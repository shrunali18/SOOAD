<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'project');
define('DB_USER', 'root');
define('DB_PASS', '');
$con=mysqli_connect(DB_HOST,DB_USER,DB_PASS) or die ("Failed to connect to database:" . mysqli_error($con));
$db=mysqli_select_db($con, DB_NAME) or die ("Failed to connect to MySQL :" . mysqli_error($con));


function NewUser($con){
	$fname = $_POST['first_name'];
	$lname = $_POST['last_name'];
	$address = $_POST['area'];
	$city = $_POST['city_name'];
	$state = $_POST['state_name'];
	$email = $_POST['email'];
	$password = md5($_POST['pass']);
	$query = "INSERT INTO users(fullname,username,email,password) VALUES ('$fullname','$username', '$email','$password')";
	$data = mysqli_query($con,$query) or die (mysqli_error($con));
	if($data){
		echo"YOUR REGISTRATION IS COMPLETE." ;
	}
}


	if (isset($_POST['submit']))
{
//echo "signed up"
Signup($con);
}



?>