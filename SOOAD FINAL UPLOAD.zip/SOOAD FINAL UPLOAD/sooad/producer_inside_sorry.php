<?php
	$servername ="localhost";
	$username ="root";
	$password ="";
	$dbname ="project";
	
	//create connection
	$conn1 = new mysqli($servername,$username,$password,$dbname);
	//if connection
	if($conn1=connect_error)
	{
		die("Connection failed :" . $conn1=connect_error);
	}
	$conn1=close();
?>