# SOOAD
Ola for agricultural where we connect the farmers to the buyers 
