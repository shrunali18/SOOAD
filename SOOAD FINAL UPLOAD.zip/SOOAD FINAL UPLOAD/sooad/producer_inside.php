<?php
	$servername ="localhost";
	$username ="root";
	$password ="";
	$dbname ="sooad";
	
	$conn1=new mysqli($servername,$username,$password,$dbname);
	
	if($conn1->connect_error)
	{
		die("Connection error :" .$conn1->connect_error);
	}
	
	
	if( isset($_POST['crop']) && !empty($_POST['crop']) AND isset($_POST['quantity']) && !empty($_POST['quantity']) ){//  If statement is true run code between brackets
	
	$crop = $_POST['crop'];
	$quantity = $_POST['quantity'];
	
	} else
	{
	echo "dfsdf";
	
	}
	
	$sql = "INSERT INTO producer_inside (crop , quantity) VALUES('$crop','$quantity')";
	
	/*$result = mysqli_query($conn1, "SELECT * FROM buyer_inside WHERE crop = '$crops' and quantity <= '$quantity'") or die("failed to query" .mysqli_error($conn1));
	$row = mysqli_fetch_assoc($result);

if($row['crop']==$email && $row['password']==$password)
{
	echo "LOGIN SUCCESSFUL , WELCOME".$row['email'];
	$_SESSION['name']=$email;
	header("location:buyer_inside.html");
}
else
{
	echo "incorrect email or password";
}
*/
	if($conn1->query($sql)===TRUE)
	{
		echo "New record created successfully.";
		header("location:producer_inside_congrats.html");
	}
	else
	{
		echo "error.";
		header("location:producer_inside_sorry.html");
	}
	$conn1-> close();
?>