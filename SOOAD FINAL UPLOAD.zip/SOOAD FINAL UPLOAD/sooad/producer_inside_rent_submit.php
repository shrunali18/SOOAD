


  <?php
  session_start();
  
	$servername = "localhost";
	$username = "root";
	$password ="";
	$dbname ="sooad";
	
	$conn1=new mysqli($servername,$username,$password,$dbname);
	if($conn1->connect_error)
	{
		die("Connection error:" .$conn1->connect_error);
	}
	
	/*if(isset($_POST['submit']))
	{
	$area = (int)$_POST['area'];
	$cost_per_sf = (int)$_POST['cost_per_sf'];
	
	$price= $area*$cost_per_sf;
	}*/
	//header("location:producer_inside_rent_submit.html");
	
	$conn1->close();
?>

<!DOCTYPE html>
  <html>
    <head>
    <title>Rent</title>
      <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.7/css/materialize.css" />

      <!--Let browser know website is optimized for mobile-->
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
         <style type="text/css">
          fieldset{
            padding-right: 40px; padding-left: 40px;
            padding-bottom: 30px; padding-top: 10px;
          }
      </style>
   
    </head>

    <body background="bg.jpg">
   <!-- {
           background-image: url("http://subtlepatterns2015.subtlepatterns.netdna-cdn.com/patterns/sayagata-400px.png");
     } --> 

<div class="container">
<h1 font size: "4" ; color= "696969" align="CENTER" class= "grey-text text-darken-1">RENT YOUR LAND</h1>
<hr>
<br>
      <div class="row">
      <div class="col s1 m4 l3"></div>
    <!--<form class="col s12 m4 l6">-->
    <fieldset style="border: 5px solid  #FF7F50 ; border-radius: 6px ;">
      <div class="row">
        <div class="input-field col s12"> 

        
        <form action="producer_inside_rent_submit.php" name="file" method="post">

  
		
		
        <h3>Estimated Price :<input id="price" name="price" class="" value=""></h3>
		<script>
		var p=<?php echo json_encode($_SESSION['price']); ?>;
		document.write(p);
		document.getElementbyId('price').value=p;
		</script>
        <h3></h3>

      

      <a href="producer_inside_rent_agree.html"><button class="btn waves-effect waves-light" type="button" name="action">Agree
    <i class="material-icons right">send</i>
  </button></a>

  <a href="producer_inside_rent_disagree.html"><button class="btn waves-effect waves-light" type="button" name="action">Disagree
    <i class="material-icons right">send</i>
  </button></a>
 </form>
  </fieldset>
   
    <div class="col s12 m4 l3"></div>
  </div>

         


<!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.7/js/materialize.min.js"></script>
</div>  
  </body>
  </html>

 <!--  <footer class="page-footer">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Footer</h5>
                <p class="grey-text text-lighten-4">You can use rows and columns here to organize your footer content.</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Links</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="#!">LINK TO MOODLE</a></li>
                  
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2016 Copyright Text
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
          </div>
        </footer> -->

		
		
        

