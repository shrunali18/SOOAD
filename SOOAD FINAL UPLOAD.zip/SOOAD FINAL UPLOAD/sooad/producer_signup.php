<?php

//	echo phpinfo();
	//echo "fdfdf";
	//die;

		error_reporting(-1);
	$servername ="localhost";
	$username = "root";
	$password ="";
	$dbname ="sooad";
	
	$conn1=new mysqli($servername,$username,$password,$dbname);
	if($conn1->connect_error)
	{
		die("Connection error :" .$conn1->connect_error);
	}
	
	
		
	
	/*$image = addslashes(file_get_contents($_FILES['file']['name'])); //SQL Injection defence!
	$image_name = addslashes($_FILES['file']['tmp_name']);
	$MY_FILE = $_FILES['aadhar']['name'];
	$file = fopen($MY_FILE, 'r');
	$file_contents = fread($file, filesize($MY_FILE));
	fclose($file);
	/* We need to escape some stcharacters that might appear in  file_contents,so do that now, before we begin the query.*/
 
	//$file_contents = addslashes($file_contents);
	//$aadhar_card = $_POST['file'];
	
	//so the form is not empty when submitted
	
	
		$fname = $_POST['first_name'];
	$lname = $_POST['last_name'];
	$name=$fname.$lname;
	$phone_no = $_POST['phone_number'];
	$address = $_POST['area'];
	$city = $_POST['city_name'];
	$state = $_POST['state_name'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$aadhar_card =$_POST['aadhar_card'];
	
	
	
	
	$sql = "INSERT INTO producer VALUES('$name','$phone_no','$address','$city','$state','$email','$password','$aadhar_card');";
	if($conn1->query($sql)===TRUE)
	{

		echo "New record created successfully";header("location:index.html");


	}
	else
	{
		echo "error";
	}
			//header("location:index.html");

	$conn1->close();
?>