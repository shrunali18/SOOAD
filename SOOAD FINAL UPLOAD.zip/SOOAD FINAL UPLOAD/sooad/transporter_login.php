<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "sooad";
	
	$conn1 = new mysqli($servername,$username,$password,$dbname);
	if($conn1->connect_error)
	{
		die("Connection error :" .$conn1->connect_error);
	}
	
	if( isset($_POST['email']) && !empty($_POST['email']) AND isset($_POST['password']) && !empty($_POST['password']) )//  If statement is true run code between brackets
		{
			
	$email = $_POST['email'];
	$password = $_POST['password'];
	


		}
$result = mysqli_query($conn1, "SELECT * FROM transporter WHERE email = '$email' and password = '$password'") or die("failed to query" .mysqli_error($conn1));
$row = mysqli_fetch_assoc($result);

if($row['email']==$email && $row['password']==$password )
{
	echo "LOGIN SUCCESSFUL , WELCOME".$row['email'];
	$_SESSION['name']=$email;
	header("location:transporter_inside.html");
}
else
{
	echo "incorrect email or password";
}
		
		
		$conn1->close();

		
?>