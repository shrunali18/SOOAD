<?php
	$servername ="localhost";
	$username ="root";
	$password ="";
	$dbname ="sooad";
	
	$conn1 = new mysqli($servername,$username,$password,$dbname);
	if($conn1->connect_error)
	{
		die("Connection error:".$conn1->connect_error);
	}
	
	if( isset($_POST['first_name']) && !empty($_POST['first_name']) AND isset($_POST['last_namename']) && !empty($_POST['last_name']))
	{//  If statement is true run code between brackets
		echo "dfsdf";
	} else
	{
	
	$fname = $_POST['first_name'];
	$lname = $_POST['last_name'];
	$name=$fname.$lname;
	$phone_no = $_POST['phone_number'];
	$address = $_POST['area'];
	$complaint = $_POST['complaint'];
	/*$city = $_POST['city_name'];
	$state = $_POST['state_name'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$shopid = $_POST['Shopkeeper_ID'];
	$aadhar_card = $_POST['aadhar'];*/
	}
	
	$sql = " INSERT INTO complaint(name,phone_no,address,complaint) VALUES('$name','$phone_no','$address','$complaint')";//sql statement
	
	if($conn1->query($sql)===TRUE)
	{
		echo "New record created successfully ";
		header("location:complaint_inside.html");
	}
	else
	{
		echo "wrong";
	}
	
	
	
	
	
	$conn1->close();
?>