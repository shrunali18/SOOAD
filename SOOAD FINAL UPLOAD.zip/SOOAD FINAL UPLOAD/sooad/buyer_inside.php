<?php
	$servername ="localhost";
	$username ="root";
	$password ="";
	$dbname = "sooad";
	
	$conn1=new mysqli($servername,$username,$password,$dbname);
	if($conn1->connect_error)
	{
		die("Connection error :".$conn1->connect_error);
	}
	$requirements = $_POST['crops'];
	$quantity = $_POST['quantity'];
	
	echo $requirements."<br>";
	echo $quantity;
	
	/*$store = "INSERT INTO transporter_inside(requirements,quantity,v_capacity) VALUES('$requirements','$quantity');";
		if($conn1->query($store)===TRUE)
		{
			echo "hurray";
		}
*/
	
	$sql = " SELECT * FROM producer_inside where crop like '$requirements' AND quantity>=$quantity;";//WHERE crop LIKE '$requirements' ;";//WHERE quantity >= $quantity; ";//crop LIKE '$requirements' ;";//AND quantity >= $quantity;";
	
	$result=$conn1->query($sql);
	$rows=mysqli_num_rows($result);

	if($rows != 0)
	{
		echo "New record successfully $rows ";
		header("location: buyer_inside_congrats.html");
	}
	else
	{
		echo "error";
		header("location: buyer_inside_sorry.html");
	}
	$conn1->close();
?>