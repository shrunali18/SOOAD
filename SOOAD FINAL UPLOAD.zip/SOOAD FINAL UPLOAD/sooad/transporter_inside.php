<?php
//session_start();
	$servername = "localhost";
	$username = "root";
	$password ="";
	$dbname = "sooad";
	
	$conn1=new mysqli($servername,$username,$password,$dbname);
	
	if($conn1->connect_error)
	{
		die("Connection error :" .$conn1->connect_error);
	}
	
	$v_capacity = $_POST['capacity'];
	
	//$store = "INSERT INTO transporter_inside(v_capacity) VALUES('$v_capacity')";
	
	/*
	$requirements = $_POST['crops'];
	$quantity = $_POST['quantity'];
	
	echo $requirements."<br>";
	echo $quantity;
	
	<script>
		var p=<?php echo json_encode($_SESSION['requirements','quantity','v_capacity']); ?>;
		document.write(p);
		document.getElementbyId('requirements','quantity','v_capacity').value=p;
		</script>
	
	
	
	$sql = " SELECT * FROM transporter_inside where crop like '$requirements' AND quantity>= $quantity  ;";//WHERE crop LIKE '$requirements' ;";//WHERE quantity >= $quantity; ";//crop LIKE '$requirements' ;";//AND quantity >= $quantity;";
	
	$result=$conn1->query($sql);
	$rows=mysqli_num_rows($result);
	
	if($rows != 0 )
	{
		echo "New record successfully $rows ";
		
		header("location: transporter_inside_congrats.html");
	}
	else
	{
		echo "error";
		header("location: transporter_inside_sorry.html");
	}
	*/
	$sql = " INSERT INTO transporter_inside(v_capacity) VALUES('$v_capacity');";
	if($conn1->query($sql)===TRUE)
	{
		echo "New record created ";
		header("location: transporter_inside_congrats.html");
	}
	else
	{
		echo "error";
		header("location: transporter_inside_sorry.html");
	}
	$conn1->close();
	
?>