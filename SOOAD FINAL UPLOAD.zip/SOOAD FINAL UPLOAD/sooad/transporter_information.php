<?php

session_start();
	$servername = "localhost";
	$username = "root";
	$password ="";
	$dbname = "sooad";
	
	$conn1=new mysqli($servername,$username,$password,$dbname);
	
	if($conn1->connect_error)
	{
		die("Connection error :" .$conn1->connect_error);
	}
		
	$requirements = $_POST['crops'];
	$quantity = $_POST['quantity'];
	
	$v_capacity = $_POST['capacity'];
	$sql=" INSERT INTO transporter_inside(requirements,quantity,v_capacity) VALUES('$v_capacity');";
	
	
	if($conn1->query($sql)===TRUE)
	{
		echo "New record created.";
		$_SESSION['requirements'];
		$_SESSION['quantity'];
		$_SESSION['v_capacity'];
			header("location:producer_inside.php");

	}
	else
	{
		echo "error";
	}
	
	
	/*
	
if($conn1->query($sql)===TRUE)
	{
		echo "New record created ";
		header("location: transporter_inside_congrats.html");
	}
	else
	{
		echo "error";
		header("location: transporter_inside_sorry.html");
	}*/
	$conn1->close();
	
?>