<?php
	$servername ="localhost";
	$username = "root";
	$password ="";
	$dbname ="sooad";
	
	$conn1 = new mysqli($servername,$username,$password,$dbname);
	if($conn1->connect_error)
	{
		die("Connection error :" .$conn1=connect_error);
	}
	
	
	if( isset($_POST['first_name']) && !empty($_POST['first_name']) AND isset($_POST['last_namename']) && !empty($_POST['last_name']) AND isset($_POST['email']) && !empty($_POST['email']) ){//  If statement is true run code between brackets
	
	echo "dfsdf";
	} else
	{
	
	
	$address = $_POST['address'];
	$phone_no = $_POST['phone_no'];
	$no_of_labourers = $_POST['no_of_labourers'];
	$equipments=$_POST['equipments'];
	}
	
	$sql = "INSERT INTO producer_inside_help VALUES('$address','$phone_no','$no_of_labourers','$equipments')";
	
	if($conn1->query($sql)===TRUE)
	{
		echo "New record created successfully";
	}
	else
	{
		echo "error";
	}
	header("location:producer_inside_help_submit.html");
 $conn1->close();
?>